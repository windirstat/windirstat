﻿// WinDirStat - Directory Statistics
// Copyright © WinDirStat Team
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 2 of the License, or
// at your option any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

#include "pch.h"
#include "FinderNtfs.h"

enum ATTRIBUTE_TYPE_CODE : ULONG
{
    AttributeStandardInformation = 0x10,
    AttributeFileName = 0x30,
    AttributeData = 0x80,
    AttributeReparsePoint = 0xC0,
    AttributeEnd = 0xFFFFFFFF,
};

using FILE_RECORD = struct FILE_RECORD
{
    ULONG Signature;
    USHORT UsaOffset;
    USHORT UsaCount;
    ULONGLONG Lsn;
    USHORT SequenceNumber;
    USHORT LinkCount;
    USHORT FirstAttributeOffset;
    USHORT Flags;
    ULONG FirstFreeByte;
    ULONG BytesAvailable;
    ULONGLONG BaseFileRecordNumber : 48;
    ULONGLONG BaseFileRecordSequence : 16;
    USHORT NextAttributeNumber;
    USHORT SegmentNumberHighPart;
    ULONG SegmentNumberLowPart;

    constexpr ULONGLONG SegmentNumber() const noexcept
    {
        return static_cast<ULONGLONG>(SegmentNumberHighPart) << 32ul | SegmentNumberLowPart;
    }

    constexpr bool IsValid() const noexcept
    {
        return Signature == 0x454C4946; // 'FILE'
    }
    constexpr bool IsInUse() const noexcept
    {
        return Flags & 0x0001;
    }

    constexpr bool IsDirectory() const noexcept
    {
        return Flags & 0x0002;
    }
};

using ATTRIBUTE_RECORD = struct ATTRIBUTE_RECORD
{
    ATTRIBUTE_TYPE_CODE TypeCode;
    ULONG RecordLength;
    UCHAR FormCode;
    UCHAR NameLength;
    USHORT NameOffset;
    USHORT Flags;
    USHORT Instance;

    union
    {
        struct
        {
            ULONG ValueLength;
            USHORT ValueOffset;
            UCHAR Reserved[2];
        } Resident;

        struct
        {
            LONGLONG LowestVcn;
            LONGLONG HighestVcn;
            USHORT DataRunOffset;
            USHORT CompressionSize;
            UCHAR Padding[4];
            ULONGLONG AllocatedLength;
            ULONGLONG FileSize;
            ULONGLONG ValidDataLength;
            ULONGLONG Compressed;
        } Nonresident;
    } Form;

    constexpr bool IsNonResident() const noexcept
    {
        return FormCode & 0x0001;
    }

    constexpr bool IsCompressed() const noexcept
    {
        return Flags & 0x0001;
    }

    constexpr bool IsSparse() const noexcept
    {
        return Flags & 0x8000;
    }

    ATTRIBUTE_RECORD* next() const noexcept
    {
        return ByteOffset<ATTRIBUTE_RECORD>(const_cast<ATTRIBUTE_RECORD*>(this), RecordLength);
    }

    static constexpr std::pair<ATTRIBUTE_RECORD*, ATTRIBUTE_RECORD*> bounds(FILE_RECORD* FileRecord, auto TotalLength) noexcept
    {
        return {
            ByteOffset<ATTRIBUTE_RECORD>(FileRecord, FileRecord->FirstAttributeOffset),
            ByteOffset<ATTRIBUTE_RECORD>(FileRecord, FileRecord->FirstAttributeOffset + TotalLength)
        };
    }
};

using FILE_NAME = struct FILE_NAME
{
    ULONGLONG ParentDirectory : 48;
    ULONGLONG ParentSequence : 16;
    LONGLONG CreationTime;
    LONGLONG LastModificationTime;
    LONGLONG MftChangeTime;
    LONGLONG LastAccessTime;
    LONGLONG AllocatedLength;
    LONGLONG FileSize;
    ULONG FileAttributes;
    USHORT PackedEaSize;
    USHORT Reserved;
    UCHAR FileNameLength;
    UCHAR Flags;
    WCHAR FileName[1];

    constexpr bool IsShortNameRecord() const noexcept
    {
        return Flags == 0x02;
    }
};

using STANDARD_INFORMATION = struct STANDARD_INFORMATION
{
    FILETIME CreationTime;
    FILETIME LastModificationTime;
    FILETIME MftChangeTime;
    FILETIME LastAccessTime;
    ULONG FileAttributes;
};

bool FinderNtfsContext::LoadRoot(CItem* driveitem)
{
    // Trim off excess characters
    std::wstring volumePath = driveitem->GetPathLong();
    while (!volumePath.empty() && volumePath.back() == L'\\') volumePath.pop_back();
    if (!volumePath.empty() && volumePath[0] != L'\\' && volumePath[0] != L'/') volumePath.insert(0, L"\\\\.\\");

    // Open volume handle with FILE_FLAG_OVERLAPPED for asynchronous I/O
    SmartPointer<HANDLE> volumeHandle(CloseHandle, CreateFile(volumePath.c_str(), FILE_READ_DATA | FILE_READ_ATTRIBUTES | SYNCHRONIZE,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING,
        FILE_FLAG_NO_BUFFERING | FILE_FLAG_OVERLAPPED, nullptr));
    if (volumeHandle == INVALID_HANDLE_VALUE) return false;

    // Get volume information
    NTFS_VOLUME_DATA_BUFFER volumeInfo = {};
    ULONG bytesReturned;
    if (!DeviceIoControl(volumeHandle, FSCTL_GET_NTFS_VOLUME_DATA, nullptr, 0, &volumeInfo, sizeof(volumeInfo), &bytesReturned, nullptr)) return
        false;

    // Get MFT retrieval pointers
    SmartPointer<HANDLE> fileHandle(CloseHandle, CreateFile((volumePath + L"\\$MFT::$DATA").c_str(), FILE_READ_ATTRIBUTES | SYNCHRONIZE,
        FILE_SHARE_WRITE | FILE_SHARE_READ | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING,
        FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_NO_BUFFERING, nullptr));
    if (fileHandle == INVALID_HANDLE_VALUE) return {};

    std::vector<BYTE> dataRunsBuffer(sizeof(RETRIEVAL_POINTERS_BUFFER) + 32 * sizeof(LARGE_INTEGER));
    STARTING_VCN_INPUT_BUFFER input = {};
    while (!DeviceIoControl(fileHandle, FSCTL_GET_RETRIEVAL_POINTERS, &input, sizeof(input), dataRunsBuffer.data(),
        static_cast<DWORD>(dataRunsBuffer.size()), &bytesReturned, nullptr) && GetLastError() == ERROR_MORE_DATA)
    {
        dataRunsBuffer.resize(dataRunsBuffer.size() * 2);
    }
    if (GetLastError() != ERROR_SUCCESS && GetLastError() != ERROR_MORE_DATA)
    {
        return false;
    }

    // Extract data run origins and cluster counts
    RETRIEVAL_POINTERS_BUFFER* retrievalBuffer = ByteOffset<RETRIEVAL_POINTERS_BUFFER>(dataRunsBuffer.data(), 0);
    std::vector<std::pair<ULONGLONG, ULONGLONG>> dataRuns(retrievalBuffer->ExtentCount, {});
    for (const auto i : std::views::iota(0u, retrievalBuffer->ExtentCount))
    {
        dataRuns[i] = { retrievalBuffer->Extents[i].Lcn.QuadPart,
            retrievalBuffer->Extents[i].NextVcn.QuadPart - (i == 0
                ? retrievalBuffer->StartingVcn.QuadPart : retrievalBuffer->Extents[i - 1].NextVcn.QuadPart) };
    }

    // Process MFT records
    std::for_each(std::execution::par, dataRuns.begin(), dataRuns.end(), [&](const auto& dataRun)
    {
        constexpr size_t bufferSize = 4ull * 1024 * 1024;
        thread_local std::unique_ptr<UCHAR, decltype(&_aligned_free)> buffer(
            static_cast<UCHAR*>(_aligned_malloc(bufferSize, volumeInfo.BytesPerSector)), &_aligned_free);

        const auto& [clusterStart, clusterCount] = dataRun;

        // Enumerate over the data run in buffer-sized chunks
        ULONGLONG bytesToRead = clusterCount * volumeInfo.BytesPerCluster;
        LARGE_INTEGER fileOffset{ .QuadPart = static_cast<LONGLONG>(clusterStart * volumeInfo.BytesPerCluster) };
        thread_local SmartPointer<HANDLE> event(CloseHandle, CreateEvent(nullptr, FALSE, FALSE, nullptr));
        for (ULONG bytesRead = 0; bytesToRead > 0; bytesToRead -= bytesRead, fileOffset.QuadPart += bytesRead)
        {
            // Animate pacman
            driveitem->UpwardDrivePacman();

            // Set file pointer for synchronous read
            const ULONG bytesThisRead = static_cast<ULONG>(min(bytesToRead, bufferSize));
            OVERLAPPED overlapped = { .Offset = fileOffset.LowPart, .OffsetHigh = static_cast<DWORD>(fileOffset.HighPart), .hEvent = event };
            if (ReadFile(volumeHandle, buffer.get(), bytesThisRead, &bytesRead, &overlapped) == 0)
            {
                if (GetLastError() != ERROR_IO_PENDING ||
                    WaitForSingleObject(event, INFINITE) != WAIT_OBJECT_0 ||
                    GetOverlappedResult(volumeHandle, &overlapped, &bytesRead, FALSE) == 0)
                {
                    VTRACE(L"ERROR: Failed to read MFT data.");
                    break;
                }
            }

            for (ULONG offset = 0; offset + volumeInfo.BytesPerFileRecordSegment <= bytesRead; offset += volumeInfo.BytesPerFileRecordSegment)
            {
                // Process MFT record inline
                const auto fileRecord = ByteOffset<FILE_RECORD>(buffer.get(), offset);

                // Bounds check for fixup array access
                if (fileRecord->UsaOffset + sizeof(USHORT) * fileRecord->UsaCount > volumeInfo.BytesPerFileRecordSegment) continue;
                if (fileRecord->FirstAttributeOffset >= volumeInfo.BytesPerFileRecordSegment) continue;

                // Apply fixup (NTFS MFTs always have a 512 byte sector size)
                constexpr auto MFT_RECORD_SECTOR_SIZE = 512u;
                constexpr auto wordsPerSector = MFT_RECORD_SECTOR_SIZE / sizeof(USHORT);
                const auto fixupArray = ByteOffset<USHORT>(fileRecord, fileRecord->UsaOffset);
                const auto usn = fixupArray[0];
                const auto recordWords = reinterpret_cast<PUSHORT>(ByteOffset<UCHAR>(buffer.get(), offset));
                bool skipRecord = false;
                if (fileRecord->UsaCount > 0) for (const auto i : std::views::iota(1u, fileRecord->UsaCount))
                {
                    const auto sectorEnd = recordWords + i * wordsPerSector - 1;
                    if (*sectorEnd == usn) *sectorEnd = fixupArray[i];
                    else { skipRecord = true; break; }
                }

                // Skip if corrupt record detected
                if (skipRecord) [[unlikely]] break;

                // Only process records with valid headers and are in use
                if (!fileRecord->IsValid() || !fileRecord->IsInUse()) continue;
                const auto currentRecord = fileRecord->SegmentNumber();
                const auto baseRecordIndex = fileRecord->BaseFileRecordNumber > 0 ? fileRecord->BaseFileRecordNumber : currentRecord;
                FileRecordBase* baseRecordPtr = nullptr;
                if (std::scoped_lock lock(m_baseFileRecordMutex); true)
                {
                    baseRecordPtr = &m_baseFileRecordMap[baseRecordIndex];
                }
                auto& baseRecord = *baseRecordPtr;

                for (auto [curAttribute, endAttribute] = ATTRIBUTE_RECORD::bounds(fileRecord, volumeInfo.BytesPerFileRecordSegment); curAttribute <
                    endAttribute && curAttribute->TypeCode != AttributeEnd; curAttribute = curAttribute->next())
                {
                    if (curAttribute->TypeCode == AttributeStandardInformation)
                    {
                        if (curAttribute->IsNonResident()) continue;
                        const auto si = ByteOffset<STANDARD_INFORMATION>(curAttribute, curAttribute->Form.Resident.ValueOffset);
                        baseRecord.LastModifiedTime = si->LastModificationTime;
                        baseRecord.Attributes = si->FileAttributes;
                        if (fileRecord->IsDirectory()) baseRecord.Attributes |= FILE_ATTRIBUTE_DIRECTORY;
                        if (baseRecord.Attributes == 0) baseRecord.Attributes = FILE_ATTRIBUTE_NORMAL;
                    }
                    else if (curAttribute->TypeCode == AttributeFileName)
                    {
                        if (curAttribute->IsNonResident()) continue;
                        const auto fn = ByteOffset<FILE_NAME>(curAttribute, curAttribute->Form.Resident.ValueOffset);
                        if (fn->IsShortNameRecord() ||
                            (fn->FileNameLength == 1 && wcscmp(fn->FileName, L".") == 0) ||
                            (fn->FileNameLength == 2 && wcscmp(fn->FileName, L"..") == 0)) continue;
                        
                        std::scoped_lock lock(m_parentToChildMutex);
                        auto& children = m_parentToChildMap.try_emplace(fn->ParentDirectory).first->second;
                        children.emplace_back(std::wstring{ fn->FileName, fn->FileNameLength }, baseRecordIndex);
                    }
                    else if (curAttribute->TypeCode == AttributeData)
                    {
                        // Special case for WofCompressedData files
                        if (const WCHAR* streamName = ByteOffset<WCHAR>(curAttribute, curAttribute->NameOffset); curAttribute->NameLength > 0)
                        {
                            if (std::wstring_view(streamName, curAttribute->NameLength) == L"WofCompressedData")
                            {
                                baseRecord.PhysicalSize = curAttribute->IsNonResident() ?
                                    curAttribute->Form.Nonresident.AllocatedLength :
                                    (curAttribute->Form.Resident.ValueLength + 7) & ~7;
                            }

                            continue;
                        }

                        // Default stream processing
                        if (curAttribute->IsNonResident())
                        {
                            if (curAttribute->Form.Nonresident.LowestVcn != 0) continue;
                            baseRecord.LogicalSize = curAttribute->Form.Nonresident.FileSize;
                            baseRecord.PhysicalSize = (curAttribute->IsCompressed() || curAttribute->IsSparse()) ?
                                curAttribute->Form.Nonresident.Compressed : curAttribute->Form.Nonresident.AllocatedLength;
                        }
                        else
                        {
                            baseRecord.LogicalSize = curAttribute->Form.Resident.ValueLength;
                            baseRecord.PhysicalSize = (curAttribute->Form.Resident.ValueLength + 7) & ~7;
                        }
                    }
                    else if (curAttribute->TypeCode == AttributeReparsePoint)
                    {
                        if (curAttribute->IsNonResident()) continue;
                        const auto fn = ByteOffset<Finder::REPARSE_DATA_BUFFER>(curAttribute, curAttribute->Form.Resident.ValueOffset);
                        baseRecord.ReparsePointTag = fn->ReparseTag;

                        // Treat WOF files as compressed
                        if (fn->ReparseTag == IO_REPARSE_TAG_WOF)
                        {
                            baseRecord.Attributes |= FILE_ATTRIBUTE_COMPRESSED;
                        }

                        if (Finder::IsJunction(*fn))
                        {
                            baseRecord.ReparsePointTag = IO_REPARSE_TAG_JUNCTION_POINT;
                        }
                    }
                }
            }
        }
    });

    // Verify root node exists
    if (!m_parentToChildMap.contains(NtfsNodeRoot))
    {
        return false;
    }

    driveitem->SetIndex(NtfsNodeRoot);
    m_isLoaded = true;
    return true;
}

bool FinderNtfs::FindNext()
{
    if (m_recordIterator == m_recordIteratorEnd) return false;
    m_index = m_recordIterator->BaseRecord;
    const auto it = m_master->m_baseFileRecordMap.find(m_index);
    if (it == m_master->m_baseFileRecordMap.end()) return false;
    m_currentRecord = &it->second;
    m_currentRecordName = &(*m_recordIterator);
    ++m_recordIterator;

    return true;
}

bool FinderNtfs::FindFile(const CItem* item)
{
    m_base = item->GetPath();
    const auto result = m_master->m_parentToChildMap.find(item->GetIndex());
    if (result == m_master->m_parentToChildMap.end()) return false;
    m_recordIteratorEnd = result->second.end();
    m_recordIterator = result->second.begin();
    return FindNext();
}

DWORD FinderNtfs::GetAttributes() const
{
    return m_currentRecord->Attributes;
}

ULONGLONG FinderNtfs::GetIndex() const
{
    return m_currentRecordName->BaseRecord;
}

DWORD FinderNtfs::GetReparseTag() const
{
    return m_currentRecord->ReparsePointTag;
}

std::wstring FinderNtfs::GetFileName() const
{
    return m_currentRecordName->FileName;
}

ULONGLONG FinderNtfs::GetFileSizePhysical() const
{
    return m_currentRecord->PhysicalSize;
}

ULONGLONG FinderNtfs::GetFileSizeLogical() const
{
    return m_currentRecord->LogicalSize;
}

FILETIME FinderNtfs::GetLastWriteTime() const
{
    return m_currentRecord->LastModifiedTime;
}

std::wstring FinderNtfs::GetFilePath() const
{
    // Get full path to folder or file
    std::wstring path = (m_base.back() == L'\\') ?
        (m_base + GetFileName()) :
        (m_base + L"\\" + GetFileName());

    // Strip special dos chars
    if (path.starts_with(s_dosUNCPath)) return L"\\\\" + path.substr(s_dosUNCPath.length());
    if (path.starts_with(s_dosPath)) return path.substr(s_dosPath.length());
    return path;
}

bool FinderNtfs::IsReserved() const
{
    return m_index < FinderNtfsContext::NtfsReservedMax;
}
